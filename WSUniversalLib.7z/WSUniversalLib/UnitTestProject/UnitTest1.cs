﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using WSUniversalLib;

namespace UnitTestProject
{
    [TestClass]
    public class UnitTest1
    {
        //Простые
        [TestMethod]
        public void TestMethodAreEqualTrue1()
        {
            int productType = 1, materialType = 1, count = 10;
            int width = 20, length = 20;
            double except = 4413;
            int actual = Calculation.GetQuantityForProduct(productType, materialType, count, width, length);
            Assert.AreEqual(except, actual);
        }

        [TestMethod]
        public void TestMethodAreEqualTrue2()
        {
            int productType = 2, materialType = 2, count = 20;
            int width = 20, length = 30;
            int except = 30036;
            int actual = Calculation.GetQuantityForProduct(productType, materialType, count, width, length);
            Assert.AreEqual(except, actual);
        }

        [TestMethod]

        public void TestMethodAreEqualTrue3()
        {
            int productType = 3, materialType = 1, count = 3;
            int width = 30, length = 50;
            int except = 38049;
            int actual = Calculation.GetQuantityForProduct(productType, materialType, count, width, length);
            Assert.AreEqual(except, actual);
        }

        [TestMethod]
        public void TestMethodAreNotEqualTrue()
        {
            int productType = 3, materialType = 1, count = 15;
            int width = 20, length = 45;
            int except = 114148;
            int actual = Calculation.GetQuantityForProduct(productType, materialType, count, width, length);
            Assert.AreNotEqual(except, actual);
        }

        [TestMethod]
        public void TestMethodIsTrueTrue()
        {
            int productType = 2, materialType = 1, count = 25;
            int width = 10, length = 15;
            int except = 9403;
            int actual = Calculation.GetQuantityForProduct(productType, materialType, count, width, length);
            Assert.IsTrue(actual == except);
        }
        [TestMethod]
        public void TestMethodIsFalseFalse()
        {
            int productType = 1, materialType = 2, count = 12;
            float width = 15, length = 35;
            int except = 114148;
            int actual = Calculation.GetQuantityForProduct(productType, materialType, count, width, length);
            Assert.IsFalse(actual == except);

        }
        [TestMethod]
        public void TestMethodIsTypeTrueInt()
        {
            int productType = 2, materialType = 2, count = 8;
            int width = 2, length = 8;
            int except = Calculation.GetQuantityForProduct(productType, materialType, count, width, length);
            Assert.IsInstanceOfType(except, typeof(int));
        }
        [TestMethod]
        public void TestMethodIsTypeFalseDouble()
        {
            int productType = 3, materialType = 1, count = 18;
            int width = 8, length = 18;
            int except = Calculation.GetQuantityForProduct(productType, materialType, count, width, length);
            Assert.IsNotInstanceOfType(except, typeof(double));
        }
        [TestMethod]
        public void TestMethodIsTypeFalseString()
        {
            int productType = 3, materialType = 1, count = 15;
            int width = 20, length = 45;
            int except = Calculation.GetQuantityForProduct(productType, materialType, count, width, length);
            Assert.IsNotInstanceOfType(except, typeof(string));
        }
        [TestMethod]
        public void TestMethodIsNotNullTrue()
        {
            int productType = 3, materialType = 1, count = 15;
            int width = 20, length = 45;
            int except = Calculation.GetQuantityForProduct(productType, materialType, count, width, length);
            Assert.IsNotNull(except);
        }

        // Сложные
        [TestMethod]
        public void TestMethodIsNotNull123()
        {
            int productType = -15, materialType = -30, count = -3;
            int width = -20, length = -45;
            Assert.ThrowsException<AssertFailedException>(() => Assert.ThrowsException<SystemException>(() => Calculation.GetQuantityForProduct(productType, materialType, count, width, length)));
        }
        [TestMethod]
        public void TestMethodIsNotNull1235()
        {
            int productType = 0, materialType = 0, count = 0;
            int width = 0, length = 0;
            Assert.ThrowsException<AssertFailedException>(() => Assert.ThrowsException<SystemException>(() => Calculation.GetQuantityForProduct(productType, materialType, count, width, length)));
        }
        [TestMethod]
        public void TestMethodIsNotNull1234()
        {
            int productType = 2147483647, materialType = 2147483647, count = 2147483647;
            int width = 2147483647, length = 2147483647;
            Assert.ThrowsException<AssertFailedException>(() => Assert.ThrowsException<SystemException>(() => Calculation.GetQuantityForProduct(productType, materialType, count, width, length)));
        }
        [TestMethod]
        public void TestMethodIsNotNull123456()
        {
            int productType = 2147483647, materialType = 2147483647, count = 2147483647;
            int width = -20, length = 0;
            Assert.ThrowsException<AssertFailedException>(() => Assert.ThrowsException<SystemException>(() => Calculation.GetQuantityForProduct(productType, materialType, count, width, length)));
        }
        [TestMethod]
        public void TestMethodIsNotNull1234567()
        {
            int productType = 0, materialType = 0, count = -0;
            int width = -10, length = -20;
            Assert.ThrowsException<AssertFailedException>(() => Assert.ThrowsException<SystemException>(() => Calculation.GetQuantityForProduct(productType, materialType, count, width, length)));
        }
    }  
}
