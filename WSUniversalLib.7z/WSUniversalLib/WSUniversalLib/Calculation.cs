﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WSUniversalLib
{
    public class Calculation
    {
        public static int GetQuantityForProduct(int productType, int materialType, int count, float width, float length)
        {
            double rez;
            if (productType == 1)
            {
                if (materialType == 1)
                {
                    rez = length * width * 1.1 * count;
                    return Convert.ToInt32(rez + rez * 0.003);
                }
                else if (materialType == 2)
                {
                    rez = length * width * 1.1 * count;
                    return Convert.ToInt32(rez + rez * 0.0012);
                }
                else return -1;
            }
            else if (productType == 2)
            {
                if (materialType == 1)
                {
                    rez = length * width * 2.5 * count;
                    return Convert.ToInt32(rez + rez * 0.003);
                }
                else if (materialType == 2)
                {
                    rez = length * width * 2.5 * count;
                    return Convert.ToInt32(rez + rez * 0.0012);
                }
                else return -1;
            }
            else if (productType == 3)
            {
                if (materialType == 1)
                {
                    rez = length * width * 8.43 * count;
                    return Convert.ToInt32(rez + rez * 0.003);
                }
                else if (materialType == 2)
                {
                    rez = length * width * 8.43 * count;
                    return Convert.ToInt32(rez + rez * 0.0012);
                }
                else return -1;
            }
            else return -1;
        }
    }
}
